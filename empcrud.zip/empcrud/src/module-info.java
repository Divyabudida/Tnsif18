/**
 * 
 */
/**
 * 
 */
module samplecrud {
	requires java.sql;
}