const apiKey = '913985d4cca675085c646a51cf6239da'; // Replace with your OpenWeatherMap API key

function convertUnixTimestampToTime(unixTimestamp) {
    const date = new Date(unixTimestamp * 1000);
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const timeString = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
    return timeString;
}
document.getElementById("cityName").innerHTML = "Delhi";

const updateWeatherData = (city, response) => {
    if (city === "user") {
      console.log("in if user")
        document.getElementById("cityName").innerHTML = response.name ;
        document.getElementById("Cloud_pct").innerHTML = response.clouds.all;
        document.getElementById("temp").innerHTML = (response.main.temp - 273.15).toFixed(2);
        document.getElementById("temp2").innerHTML = (response.main.temp - 273.15).toFixed(2);
        document.getElementById("Humidity").innerHTML = response.main.humidity;
        document.getElementById("Humidity2").innerHTML = response.main.humidity;
        document.getElementById("min_temp").innerHTML = (response.main.temp_min - 273.15).toFixed(2);
        document.getElementById("max_temp").innerHTML = (response.main.temp_max - 273.15).toFixed(2);
        document.getElementById("Wind_speed").innerHTML = response.wind.speed;
        document.getElementById("Wind_speed2").innerHTML = response.wind.speed;
        document.getElementById("Wind_degrees").innerHTML = response.wind.deg;
        document.getElementById("Sunrise").innerHTML = convertUnixTimestampToTime(response.sys.sunrise);
        document.getElementById("Sunset").innerHTML = convertUnixTimestampToTime(response.sys.sunset);
    } else {
      console.log("in else")
        document.getElementById(`Cloud_pct${city}`).innerHTML = response.clouds.all;
        document.getElementById(`Humidity${city}`).innerHTML = response.main.humidity;
        document.getElementById(`max_temp${city}`).innerHTML = (response.main.temp_max - 273.15).toFixed(2);
        document.getElementById(`min_temp${city}`).innerHTML = (response.main.temp_min - 273.15).toFixed(2);
        document.getElementById(`Sunrise${city}`).innerHTML = convertUnixTimestampToTime(response.sys.sunrise);
        document.getElementById(`Sunset${city}`).innerHTML = convertUnixTimestampToTime(response.sys.sunset);
        document.getElementById(`temp${city}`).innerHTML = (response.main.temp - 273.15).toFixed(2);
        document.getElementById(`Wind_degrees${city}`).innerHTML = response.wind.deg;
        document.getElementById(`Wind_speed${city}`).innerHTML = response.wind.speed;
    }
}

const getWeather = (city, lat, lon) => {
    fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}`)
        .then(response => response.json())
        .then(response => {
            updateWeatherData(city, response);
        })
        .catch(err => console.error(err));
}

// Function to fetch weather data for default cities
const fetchDefaultCitiesWeather = () => {
    const defaultCities = [
        { name: "pune", lat: 18.5204, lon: 73.8567 },
        { name: "mumbai", lat: 19.0760, lon: 72.8777 },
        { name: "hyderabad", lat: 17.3850, lon: 78.4867 },
        { name: "chennai", lat: 13.0827, lon: 80.2707 },
        { name: "jalandhar", lat: 31.3260, lon: 75.5762 },
        { name: "lucknow", lat: 26.8467, lon: 80.9462 }
    ];

    defaultCities.forEach(city => {
        getWeather(city.name, city.lat, city.lon);
    });
}
const city="Delhi";
        fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`)
        .then(response => response.json())
        .then(response => {
            getWeather("user", 17.3850, 78.4867);
        })
        .catch(err => console.error(err));
// Fetch weather data for default cities on page load
fetchDefaultCitiesWeather();

// Event listener for the search form submission
document.getElementById("submit").addEventListener("click", (e) => {
    e.preventDefault();
    const cityName = document.getElementById("city").value.trim();

    if (cityName === "") {
        // If no city name is entered, show default city details
        const city="Delhi";
        fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`)
        .then(response => response.json())
        .then(response => {
            getWeather("user", 17.3850, 78.4867);
        })
        .catch(err => console.error(err));
        fetchDefaultCitiesWeather();
    } else {
        // Fetch weather data for the entered city
        fetch(`https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${apiKey}`)
            .then(response => response.json())
            .then(response => {
                getWeather("user", response.coord.lat, response.coord.lon);
            })
            .catch(err => console.error(err));
    }
});

const darkModeToggle = document.getElementById("darkModeToggle");
const body = document.body;

// Dark mode toggle functionality
darkModeToggle.addEventListener("change", () => {
    body.classList.toggle("dark-mode");
    const toggleText = document.getElementById("toggle-text");
    toggleText.textContent = body.classList.contains("dark-mode")
        ? "Light Mode"
        : "Dark Mode";
    localStorage.setItem("darkModeEnabled", body.classList.contains("dark-mode"));
});

// Check if dark mode was enabled from previous session
if (localStorage.getItem("darkModeEnabled") === 'true') {
    body.classList.add("dark-mode");
    darkModeToggle.checked = true;
}
